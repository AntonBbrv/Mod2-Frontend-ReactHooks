import React from "react";
import Title from "../components/common/typografy/title";

const Main = () => {
    return (
        <>
            {" "}
            <Title> Extended Hooks и Оптимизация</Title>
        </>
    );
};

export default Main;
